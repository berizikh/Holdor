package com.example.holdor;

import android.os.Bundle;
import android.widget.Toast;

import com.example.holdor.models.Info;
import com.example.holdor.models.MyAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ActivityInfo extends AppCompatActivity {

    DatabaseReference reference;
    RecyclerView recyclerView;
    ArrayList<Info> list;
    MyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        recyclerView = (RecyclerView) findViewById(R.id.myActivity);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list = new ArrayList<Info>();

        reference = FirebaseDatabase.getInstance().getReference().child("User");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot dataSnapshot1: dataSnapshot.getChildren())
                {
                    Info i = dataSnapshot1.getValue(Info.class);
                    list.add(i);
                }
                adapter = new MyAdapter(ActivityInfo.this,list);
                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(ActivityInfo.this, "Opsss..... Kesalahan terjadi.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
