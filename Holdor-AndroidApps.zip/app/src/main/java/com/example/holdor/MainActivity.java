package com.example.holdor;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import java.text.DateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loadFragment(new HomeFragment());
        BottomNavigationView bottomNavigationView = findViewById(R.id.bn_main);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);

        //getCurrentDate();

    }

    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fl_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }
    
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment = null;
        switch (item.getItemId()){
            case R.id.home_menu:
                fragment = new HomeFragment();
                break;
//            case R.id.dashboard_menu:
//                fragment = new DashboardFragment();
//                break;
//            case R.id.activity_menu:
//                fragment = new ActivityFragment();
//                break;
        }
        final boolean b = loadFragment(fragment);
        return b;

        public void openActivitiInfo (View v;)
        {
            Intent i = new Intent(this,ActivityInfo.class);
            startActivity(i);
        }

//        public void openInfo (View v)
//        {
//            Intent i = new Intent(this,InfoActivity.class);
//            startActivity(i);
//        }
    }

    public void getCurrentDate (){
        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance().format(calendar.getTime());

        Fragment someFragment = getSupportFragmentManager().findFragmentByTag("home_tag");
        View fragmentView = someFragment.getView();
        TextView textViewDate = (TextView) fragmentView.findViewById(R.id.date_text);
        textViewDate.setText("test");

        Log.w("testing", currentDate);

    }

}
