package com.example.holdor;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.text.DateFormat;
import java.util.Calendar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.holdor.models.Info;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HomeFragment extends Fragment {

    TextView textViewDate;
    TextView textTimeField;
    TextView textUserField;
    TextView textImageLink;
    ImageView imageViewProof;
    FirebaseDatabase database;
    DatabaseReference ref;

    private String key;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance().format(calendar.getTime());
        textViewDate = view.findViewById(R.id.date_text);
        textViewDate.setText(currentDate);

        imageViewProof = view.findViewById(R.id.image_proof);
//        String url="https://firebasestorage.googleapis.com/v0/b/holdor-v001.appspot.com/o/penipuan.PNG?alt=media&token=b0f02968-0724-40e2-800b-e45470815fe6";
////        Retrieved url as mentioned above
//        Glide.with(getContext()).load(url).into(imageViewProof);
        textUserField = view.findViewById(R.id.user_field);
        textTimeField = view.findViewById(R.id.time_field);
        return view;
    }
}