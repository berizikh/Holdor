package com.example.holdor.models;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class Info {
    private String accessor;
    private String access_time;
    private String access_date;
    private String image_link;

    public Info() {
    }

    public Info (String accessor, String access_time, String image_link) {
        this.accessor = accessor;
        this.access_time = access_time;
        this.access_date = access_date;
        this.image_link = image_link;
    }

    public String getAccessor() {
        return accessor;
    }
    public void setAccessor(String accessor) {
        this.accessor = accessor;
    }

    public String getAccess_time() {
        return access_time;
    }
    public void setAccess_time(String access_time) {
        this.access_time = access_time;
    }

    public String getAccess_date() {
        return access_date;
    }
    public void setAccess_date(String access_date) {
        this.access_date = access_date;
    }

    public String getImage_link() {
        return image_link;
    }

    public void setImage_link(String image_link) {
        this.image_link = image_link;
    }
}
