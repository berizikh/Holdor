package com.example.holdor.models;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;

public class FirebaseHelper {
    private FirebaseDatabase mDatabase;
    private DatabaseReference mReferenceHoldor;
    private List<Info> infos = new ArrayList<>();

    public interface DataStatus{
        void DataIsLoaded(List<Info> infos, List<String> keys);
        void DataIsInserted();
        void DataIsUpdated();
        void DataIsDeleted();
    }

    public FirebaseHelper() {
        mDatabase = FirebaseDatabase.getInstance();
        mReferenceHoldor = mDatabase.getReference("holdor");
    }

    public void readInfos(final DataStatus datasStatus) {
        mReferenceHoldor.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                infos.clear();
                List<String> keys = new ArrayList<>();
                for(DataSnapshot keyNode : dataSnapshot.getChildren()){
                    keys.add(keyNode.getKey());
                    Info info = keyNode.getValue(Info.class);
                    infos.add(info);
                }
                datasStatus.DataIsLoaded(infos, keys);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
