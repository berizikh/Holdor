package com.example.holdor.models;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.holdor.ActivityFragment;
import com.example.holdor.ActivityInfo;
import com.example.holdor.R;

import org.w3c.dom.Text;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    ActivityFragment context;
    ArrayList<Info> infos;

    public MyAdapter(ActivityInfo c, ArrayList<Info> i)
    {
        context = c;
        infos = i;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.activity_info,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.accessor.setText(infos.get(position).getAccessor());
        holder.access_time.setText(infos.get(position).getAccess_time());
        //Picasso.get().load(infos.get(position).getImageAddress()).into(holder.Bukti);
    }

    @Override
    public int getItemCount() {
        return infos.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder
    {
        TextView accessor, access_time, access_date;
        public MyViewHolder(View itemView){
            super(itemView);

            accessor = (TextView) itemView.findViewById(R.id.user_field);
            access_time = (TextView) itemView.findViewById(R.id.time_field);
            access_date = (TextView) itemView.findViewById(R.id.tanggaltext);
        }
    }
}
